import styles from './AED_AD_S1MC_List.module.scss';

export interface AED_AD_S1MC_ListProps {
  prop?: string;
}

export function AED_AD_S1MC_List({prop = 'default value'}: AED_AD_S1MC_ListProps) {
  return <div className={styles.AED_AD_S1MC_List}>AED_AD_S1MC_List {prop}</div>;
}
