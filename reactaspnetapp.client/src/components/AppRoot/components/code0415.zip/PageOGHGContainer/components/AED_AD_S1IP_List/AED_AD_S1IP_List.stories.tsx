import type {Meta, StoryObj} from '@storybook/react';

import {AED_AD_S1IP_List} from './AED_AD_S1IP_List';

const meta: Meta<typeof AED_AD_S1IP_List> = {
  component: AED_AD_S1IP_List,
};

export default meta;

type Story = StoryObj<typeof AED_AD_S1IP_List>;

export const Basic: Story = {args: {}};
