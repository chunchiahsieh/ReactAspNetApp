import styles from './AED_AD_S1SC_List.module.scss';

export interface AED_AD_S1SC_ListProps {
  prop?: string;
}

export function AED_AD_S1SC_List({prop = 'default value'}: AED_AD_S1SC_ListProps) {
  return <div className={styles.AED_AD_S1SC_List}>AED_AD_S1SC_List {prop}</div>;
}
