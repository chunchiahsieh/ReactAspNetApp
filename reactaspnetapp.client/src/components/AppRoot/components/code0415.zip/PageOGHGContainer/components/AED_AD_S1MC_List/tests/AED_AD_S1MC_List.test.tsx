import React from 'react';

import {AED_AD_S1MC_List} from '../AED_AD_S1MC_List';

describe('<AED_AD_S1MC_List />', () => {});
