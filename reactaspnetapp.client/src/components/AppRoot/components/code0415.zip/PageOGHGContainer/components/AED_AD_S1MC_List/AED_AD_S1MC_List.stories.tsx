import type {Meta, StoryObj} from '@storybook/react';

import {AED_AD_S1MC_List} from './AED_AD_S1MC_List';

const meta: Meta<typeof AED_AD_S1MC_List> = {
  component: AED_AD_S1MC_List,
};

export default meta;

type Story = StoryObj<typeof AED_AD_S1MC_List>;

export const Basic: Story = {args: {}};
