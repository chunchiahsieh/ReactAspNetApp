import type {Meta, StoryObj} from '@storybook/react';

import {AED_AD_S1SC_List} from './AED_AD_S1SC_List';

const meta: Meta<typeof AED_AD_S1SC_List> = {
  component: AED_AD_S1SC_List,
};

export default meta;

type Story = StoryObj<typeof AED_AD_S1SC_List>;

export const Basic: Story = {args: {}};
