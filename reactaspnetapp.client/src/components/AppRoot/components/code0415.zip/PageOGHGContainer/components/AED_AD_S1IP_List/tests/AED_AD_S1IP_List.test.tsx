import React from 'react';

import {AED_AD_S1IP_List} from '../AED_AD_S1IP_List';

describe('<AED_AD_S1IP_List />', () => {});
