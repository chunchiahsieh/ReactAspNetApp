import React from 'react';

import {AED_AD_S1SC_List} from '../AED_AD_S1SC_List';

describe('<AED_AD_S1SC_List />', () => {});
