import styles from './AED_AD_S1IP_List.module.scss';

export interface AED_AD_S1IP_ListProps {
  prop?: string;
}

export function AED_AD_S1IP_List({prop = 'default value'}: AED_AD_S1IP_ListProps) {
  return <div className={styles.AED_AD_S1IP_List}>AED_AD_S1IP_List {prop}</div>;
}
