import {render} from '@testing-library/react';
import {PageOGHGContainer} from '../PageOGHGContainer';

describe('<PageOGHGContainer />', () => {
    test('it should mount', () => {
        render(<PageOGHGContainer />);
    });
});
