export const CPNTree = {
  // 以下是為了多國語系所設定的物件
  locale: {
    en: "OGHG Management",
    zh: "組織型溫盤管理",
  },
  name: "PageOGHGContainer",
};
