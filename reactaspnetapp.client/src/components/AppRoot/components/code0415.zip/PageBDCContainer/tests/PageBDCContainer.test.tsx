import React from 'react';

import {PageBDCContainer} from '../PageBDCContainer';

describe('<PageBDCContainer />', () => {});
