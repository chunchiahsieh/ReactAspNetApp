import type {Meta, StoryObj} from '@storybook/react';

import {OC_RPC_List} from './OC_RPC_List';

const meta: Meta<typeof OC_RPC_List> = {
  component: OC_RPC_List,
};

export default meta;

type Story = StoryObj<typeof OC_RPC_List>;

export const Basic: Story = {args: {}};
