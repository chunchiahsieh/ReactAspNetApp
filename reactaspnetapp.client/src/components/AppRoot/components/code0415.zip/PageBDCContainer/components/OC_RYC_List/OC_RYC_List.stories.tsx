import type {Meta, StoryObj} from '@storybook/react';

import {OC_RYC_List} from './OC_RYC_List';

const meta: Meta<typeof OC_RYC_List> = {
  component: OC_RYC_List,
};

export default meta;

type Story = StoryObj<typeof OC_RYC_List>;

export const Basic: Story = {args: {}};
