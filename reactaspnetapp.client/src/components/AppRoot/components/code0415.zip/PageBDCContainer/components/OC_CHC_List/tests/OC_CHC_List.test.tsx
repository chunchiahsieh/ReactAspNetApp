import React from 'react';

import {OC_CHC_List} from '../OC_CHC_List';

describe('<OC_CHC_List />', () => {});
