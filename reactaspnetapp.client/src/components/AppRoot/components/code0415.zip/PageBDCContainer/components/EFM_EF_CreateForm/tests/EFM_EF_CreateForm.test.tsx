import React from 'react';

import {EFM_EF_CreateForm} from '../EFM_EF_CreateForm';

describe('<EFM_EF_CreateForm />', () => {});
