import React from 'react';

import {EFM_EFL_List} from '../EFM_EFL_List';

describe('<EFM_EFL_List />', () => {});
