import styles from './OC_RYC_List.module.scss';

export interface OC_RYC_ListProps {
  prop?: string;
}

export function OC_RYC_List({prop = 'default value'}: OC_RYC_ListProps) {
  return <div className={styles.OC_RYC_List}>OC_RYC_List {prop}</div>;
}
