import React from 'react';

import {BI_ViewForm} from '../BI_ViewForm';

describe('<BI_ViewForm />', () => {});
