import React from 'react';

import {OC_RYC_ViewForm} from '../OC_RYC_ViewForm';

describe('<OC_RYC_ViewForm />', () => {});
