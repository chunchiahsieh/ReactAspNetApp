import React from 'react';

import {OC_RYC_CreateForm} from '../OC_RYC_CreateForm';

describe('<OC_RYC_CreateForm />', () => {});
