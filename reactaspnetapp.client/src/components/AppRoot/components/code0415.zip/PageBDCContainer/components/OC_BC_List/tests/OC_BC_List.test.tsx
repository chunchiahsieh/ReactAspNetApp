import React from 'react';

import {OC_BC_List} from '../OC_BC_List';

describe('<OC_BC_List />', () => {});
