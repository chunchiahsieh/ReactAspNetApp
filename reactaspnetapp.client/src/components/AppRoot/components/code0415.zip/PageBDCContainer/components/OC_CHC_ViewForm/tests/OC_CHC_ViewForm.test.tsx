import React from 'react';

import {OC_CHC_ViewForm} from '../OC_CHC_ViewForm';

describe('<OC_CHC_ViewForm />', () => {});
