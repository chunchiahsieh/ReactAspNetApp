import React from 'react';

import {OC_BC_CreateForm} from '../OC_BC_CreateForm';

describe('<OC_BC_CreateForm />', () => {});
