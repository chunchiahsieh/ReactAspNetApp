import styles from './OC_BC_List.module.scss';

export interface OC_BC_ListProps {
  prop?: string;
}

export function OC_BC_List({prop = 'default value'}: OC_BC_ListProps) {
  return <div className={styles.OC_BC_List}>OC_BC_List {prop}</div>;
}
