import React from 'react';

import {OC_BC_EditForm} from '../OC_BC_EditForm';

describe('<OC_BC_EditForm />', () => {});
