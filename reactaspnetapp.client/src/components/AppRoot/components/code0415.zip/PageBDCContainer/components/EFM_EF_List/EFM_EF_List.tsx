import styles from './EFM_EF_List.module.scss';

export interface EFM_EF_ListProps {
  prop?: string;
}

export function EFM_EF_List({prop = 'default value'}: EFM_EF_ListProps) {
  return <div className={styles.EFM_EF_List}>EFM_EF_List {prop}</div>;
}
