import React from 'react';

import {OC_RPC_List} from '../OC_RPC_List';

describe('<OC_RPC_List />', () => {});
