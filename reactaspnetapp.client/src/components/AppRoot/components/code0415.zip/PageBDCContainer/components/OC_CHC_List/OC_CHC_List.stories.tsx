import type {Meta, StoryObj} from '@storybook/react';

import {OC_CHC_List} from './OC_CHC_List';

const meta: Meta<typeof OC_CHC_List> = {
  component: OC_CHC_List,
};

export default meta;

type Story = StoryObj<typeof OC_CHC_List>;

export const Basic: Story = {args: {}};
