import React from 'react';

import {BI_EditForm} from '../BI_EditForm';

describe('<BI_EditForm />', () => {});
