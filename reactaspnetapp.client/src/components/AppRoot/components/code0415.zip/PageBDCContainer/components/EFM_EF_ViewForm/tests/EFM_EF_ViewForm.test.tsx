import React from 'react';

import {EFM_EF_ViewForm} from '../EFM_EF_ViewForm';

describe('<EFM_EF_ViewForm />', () => {});
