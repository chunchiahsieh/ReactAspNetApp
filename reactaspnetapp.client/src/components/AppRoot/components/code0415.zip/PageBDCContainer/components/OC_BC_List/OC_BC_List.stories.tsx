import type {Meta, StoryObj} from '@storybook/react';

import {OC_BC_List} from './OC_BC_List';

const meta: Meta<typeof OC_BC_List> = {
  component: OC_BC_List,
};

export default meta;

type Story = StoryObj<typeof OC_BC_List>;

export const Basic: Story = {args: {}};
