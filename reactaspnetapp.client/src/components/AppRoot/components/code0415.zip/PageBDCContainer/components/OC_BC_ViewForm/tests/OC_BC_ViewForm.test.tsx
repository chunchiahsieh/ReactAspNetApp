import React from 'react';

import {OC_BC_ViewForm} from '../OC_BC_ViewForm';

describe('<OC_BC_ViewForm />', () => {});
