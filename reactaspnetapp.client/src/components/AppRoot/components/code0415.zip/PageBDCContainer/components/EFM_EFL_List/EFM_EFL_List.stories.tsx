import type {Meta, StoryObj} from '@storybook/react';

import {EFM_EFL_List} from './EFM_EFL_List';

const meta: Meta<typeof EFM_EFL_List> = {
  component: EFM_EFL_List,
};

export default meta;

type Story = StoryObj<typeof EFM_EFL_List>;

export const Basic: Story = {args: {}};
