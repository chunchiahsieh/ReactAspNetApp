import styles from './EFM_EFL_List.module.scss';

export interface EFM_EFL_ListProps {
  prop?: string;
}

export function EFM_EFL_List({prop = 'default value'}: EFM_EFL_ListProps) {
  return <div className={styles.EFM_EFL_List}>EFM_EFL_List {prop}</div>;
}
