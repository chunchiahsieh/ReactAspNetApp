import React from 'react';

import {OC_RYC_List} from '../OC_RYC_List';

describe('<OC_RYC_List />', () => {});
