import React from 'react';

import {OC_RPC_EditForm} from '../OC_RPC_EditForm';

describe('<OC_RPC_EditForm />', () => {});
