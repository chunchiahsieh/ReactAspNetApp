import styles from './OC_RPC_List.module.scss';

export interface OC_RPC_ListProps {
  prop?: string;
}

export function OC_RPC_List({prop = 'default value'}: OC_RPC_ListProps) {
  return <div className={styles.OC_RPC_List}>OC_RPC_List {prop}</div>;
}
