import React from 'react';

import {OC_RPC_ViewForm} from '../OC_RPC_ViewForm';

describe('<OC_RPC_ViewForm />', () => {});
