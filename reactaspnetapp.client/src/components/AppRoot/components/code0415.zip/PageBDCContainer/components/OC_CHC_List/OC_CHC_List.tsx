import styles from './OC_CHC_List.module.scss';

export interface OC_CHC_ListProps {
  prop?: string;
}

export function OC_CHC_List({prop = 'default value'}: OC_CHC_ListProps) {
  return <div className={styles.OC_CHC_List}>OC_CHC_List {prop}</div>;
}
