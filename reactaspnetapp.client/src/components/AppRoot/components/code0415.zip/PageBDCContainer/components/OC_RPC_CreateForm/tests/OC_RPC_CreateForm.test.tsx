import React from 'react';

import {OC_RPC_CreateForm} from '../OC_RPC_CreateForm';

describe('<OC_RPC_CreateForm />', () => {});
