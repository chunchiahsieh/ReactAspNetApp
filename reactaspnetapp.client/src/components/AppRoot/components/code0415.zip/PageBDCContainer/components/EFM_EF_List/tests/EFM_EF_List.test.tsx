import React from 'react';

import {EFM_EF_List} from '../EFM_EF_List';

describe('<EFM_EF_List />', () => {});
