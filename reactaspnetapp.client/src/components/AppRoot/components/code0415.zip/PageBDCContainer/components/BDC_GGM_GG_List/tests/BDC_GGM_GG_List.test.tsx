import React from 'react';

import {BDC_GGM_GG_List} from '../BDC_GGM_GG_List';

describe('<BDC_GGM_GG_List />', () => {});
