import React from 'react';

import {EFM_EFL_ViewForm} from '../EFM_EFL_ViewForm';

describe('<EFM_EFL_ViewForm />', () => {});
